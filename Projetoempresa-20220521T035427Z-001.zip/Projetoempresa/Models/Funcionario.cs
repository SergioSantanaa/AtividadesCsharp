namespace Projetoempresa.Models
{
    public class Funcionario
    {
        public int FuncionarioId { get; set; }
        public int Nome { get; set; }
        public int Funcao { get; set; }
        public int Idade { get; set; }
        public int Salario { get; set; }
    }
}